export default function AnalyticsPage() {
  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 transition-colors duration-300">
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold text-gray-800 dark:text-white mb-8">Analytics & Reports</h1>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 transition-transform duration-300 hover:scale-105">
            <h2 className="text-lg font-semibold text-gray-700 dark:text-gray-300 mb-2">Project Completion</h2>
            <p className="text-3xl font-bold text-[#1A2B4A] dark:text-[#00A8CC]">87%</p>
            <p className="text-sm text-gray-500 dark:text-gray-400">On schedule</p>
          </div>

          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 transition-transform duration-300 hover:scale-105">
            <h2 className="text-lg font-semibold text-gray-700 dark:text-gray-300 mb-2">Engineer Utilization</h2>
            <p className="text-3xl font-bold text-[#1A2B4A] dark:text-[#00A8CC]">78%</p>
            <p className="text-sm text-gray-500 dark:text-gray-400">Optimal capacity</p>
          </div>

          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 transition-transform duration-300 hover:scale-105">
            <h2 className="text-lg font-semibold text-gray-700 dark:text-gray-300 mb-2">Client Satisfaction</h2>
            <p className="text-3xl font-bold text-[#1A2B4A] dark:text-[#00A8CC]">92%</p>
            <p className="text-sm text-gray-500 dark:text-gray-400">Positive feedback</p>
          </div>

          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 transition-transform duration-300 hover:scale-105">
            <h2 className="text-lg font-semibold text-gray-700 dark:text-gray-300 mb-2">Revenue</h2>
            <p className="text-3xl font-bold text-[#1A2B4A] dark:text-[#00A8CC]">$1.2M</p>
            <p className="text-sm text-gray-500 dark:text-gray-400">This quarter</p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
            <h2 className="text-xl font-semibold text-gray-800 dark:text-white mb-4">Performance Overview</h2>
            <div className="h-64 bg-gray-100 dark:bg-gray-700 rounded-md flex items-center justify-center">
              <p className="text-gray-500 dark:text-gray-400">Chart placeholder</p>
            </div>
          </div>

          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
            <h2 className="text-xl font-semibold text-gray-800 dark:text-white mb-4">Recent Activity</h2>
            <ul className="space-y-4">
              <li className="flex items-start">
                <div className="bg-[#00A8CC] rounded-full h-3 w-3 mt-2 mr-3"></div>
                <div>
                  <p className="font-medium text-gray-800 dark:text-white">Project Alpha completed</p>
                  <p className="text-sm text-gray-500 dark:text-gray-400">2 hours ago</p>
                </div>
              </li>
              <li className="flex items-start">
                <div className="bg-[#00A8CC] rounded-full h-3 w-3 mt-2 mr-3"></div>
                <div>
                  <p className="font-medium text-gray-800 dark:text-white">New client onboarding</p>
                  <p className="text-sm text-gray-500 dark:text-gray-400">5 hours ago</p>
                </div>
              </li>
              <li className="flex items-start">
                <div className="bg-[#00A8CC] rounded-full h-3 w-3 mt-2 mr-3"></div>
                <div>
                  <p className="font-medium text-gray-800 dark:text-white">Quarterly review meeting</p>
                  <p className="text-sm text-gray-500 dark:text-gray-400">1 day ago</p>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}