'use client';

import React, { useState, useMemo } from 'react';
import { ChevronDown, Search, Star, Filter, X } from 'lucide-react';

export default function EngineersDirectory() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedSpecialty, setSelectedSpecialty] = useState('');
  const [selectedLevel, setSelectedLevel] = useState('');
  const [selectedRating, setSelectedRating] = useState('');
  const [darkMode, setDarkMode] = useState(false);

  const engineers = [
    {
      id: 1,
      name: 'Sarah Mitchell',
      specialty: 'Full Stack',
      skills: ['React', 'Node.js', 'PostgreSQL', 'AWS'],
      experience: 'Senior',
      rating: 4.9,
      reviews: 127,
      avatar: '👩‍💻',
    },
    {
      id: 2,
      name: 'James Chen',
      specialty: 'DevOps',
      skills: ['Kubernetes', 'Docker', 'Terraform', 'CI/CD'],
      experience: 'Senior',
      rating: 4.8,
      reviews: 89,
      avatar: '👨‍💻',
    },
    {
      id: 3,
      name: 'Emily Rodriguez',
      specialty: 'Frontend',
      skills: ['Vue.js', 'TypeScript', 'Tailwind CSS', 'WebGL'],
      experience: 'Mid-Level',
      rating: 4.7,
      reviews: 64,
      avatar: '👩‍💼',
    },
    {
      id: 4,
      name: 'Marcus Johnson',
      specialty: 'Backend',
      skills: ['Python', 'Django', 'MongoDB', 'Redis'],
      experience: 'Senior',
      rating: 4.9,
      reviews: 156,
      avatar: '👨‍💼',
    },
    {
      id: 5,
      name: 'Lisa Wang',
      specialty: 'Mobile',
      skills: ['React Native', 'Swift', 'Kotlin', 'Firebase'],
      experience: 'Mid-Level',
      rating: 4.6,
      reviews: 72,
      avatar: '👩‍💻',
    },
    {
      id: 6,
      name: 'David Thompson',
      specialty: 'Full Stack',
      skills: ['Next.js', 'GraphQL', 'Prisma', 'Vercel'],
      experience: 'Junior',
      rating: 4.5,
      reviews: 38,
      avatar: '👨‍💻',
    },
  ];

  const specialties = ['Full Stack', 'Frontend', 'Backend', 'DevOps', 'Mobile'];
  const levels = ['Junior', 'Mid-Level', 'Senior'];

  const filteredEngineers = useMemo(() => {
    return engineers.filter((engineer) => {
      const matchesSearch =
        engineer.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        engineer.skills.some((skill) =>
          skill.toLowerCase().includes(searchTerm.toLowerCase())
        );
      const matchesSpecialty =
        !selectedSpecialty || engineer.specialty === selectedSpecialty;
      const matchesLevel = !selectedLevel || engineer.experience === selectedLevel;
      const matchesRating =
        !selectedRating || engineer.rating >= parseFloat(selectedRating);

      return matchesSearch && matchesSpecialty && matchesLevel && matchesRating;
    });
  }, [searchTerm, selectedSpecialty, selectedLevel, selectedRating]);

  const clearFilters = () => {
    setSearchTerm('');
    setSelectedSpecialty('');
    setSelectedLevel('');
    setSelectedRating('');
  };

  const hasActiveFilters =
    searchTerm || selectedSpecialty || selectedLevel || selectedRating;

  const bgClass = darkMode ? 'bg-gray-900' : 'bg-white';
  const textClass = darkMode ? 'text-gray-100' : 'text-gray-900';
  const cardBgClass = darkMode ? 'bg-gray-800' : 'bg-white';
  const borderClass = darkMode ? 'border-gray-700' : 'border-gray-200';
  const inputBgClass = darkMode ? 'bg-gray-700 text-gray-100' : 'bg-gray-50 text-gray-900';

  return (
    <div className={`min-h-screen ${bgClass} transition-colors duration-300`}>
      {/* Header */}
      <header className={`border-b ${borderClass} backdrop-blur-sm sticky top-0 z-50`}>
        <div className="max-w-7xl mx-auto px-6 py-6">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h1 className={`text-4xl font-bold ${textClass}`} style={{ color: '#1A2B4A' }}>
                Engineers Directory
              </h1>
              <p className={`mt-2 ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                Find and connect with top-tier engineering talent
              </p>
            </div>
            <button
              onClick={() => setDarkMode(!darkMode)}
              className={`px-4 py-2 rounded-lg font-medium transition-all ${
                darkMode
                  ? 'bg-gray-700 text-yellow-400 hover:bg-gray-600'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              {darkMode ? '☀️' : '🌙'}
            </button>
          </div>

          {/* Search Bar */}
          <div className="relative">
            <Search className="absolute left-4 top-3.5 text-gray-400" size={20} />
            <input
              type="text"
              placeholder="Search engineers by name or skills..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className={`w-full pl-12 pr-4 py-3 rounded-lg border ${borderClass} ${inputBgClass} placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-[#00A8CC] transition-all`}
            />
          </div>
        </div>
      </header>

      {/* Filters */}
      <div className={`border-b ${borderClass} backdrop-blur-sm sticky top-[120px] z-40`}>
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex flex-wrap gap-4 items-center">
            <Filter size={18} className="text-[#00A8CC]" />

            {/* Specialty Filter */}
            <div className="relative group">
              <button className={`flex items-center gap-2 px-4 py-2 rounded-lg border ${borderClass} ${cardBgClass} hover:border-[#00A8CC] transition-all`}>
                <span className={`text-sm font-medium ${textClass}`}>
                  {selectedSpecialty || 'Specialty'}
                </span>
                <ChevronDown size={16} />
              </button>
              <div className={`absolute top-full left-0 mt-2 w-48 rounded-lg shadow-xl border ${borderClass} ${cardBgClass} opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all z-50`}>
                <button
                  onClick={() => setSelectedSpecialty('')}
                  className={`block w-full text-left px-4 py-2 text-sm ${textClass} hover:bg-[#00A8CC] hover:text-white transition-colors`}
                >
                  All Specialties
                </button>
                {specialties.map((specialty) => (
                  <button
                    key={specialty}
                    onClick={() => setSelectedSpecialty(specialty)}
                    className={`block w-full text-left px-4 py-2 text-sm ${textClass} hover:bg-[#00A8CC] hover:text-white transition-colors ${
                      selectedSpecialty === specialty ? 'bg-[#00A8CC] text-white' : ''
                    }`}
                  >
                    {specialty}
                  </button>
                ))}
              </div>
            </div>

            {/* Experience Level Filter */}
            <div className="relative group">
              <button className={`flex items-center gap-2 px-4 py-2 rounded-lg border ${borderClass} ${cardBgClass} hover:border-[#00A8CC] transition-all`}>
                <span className={`text-sm font-medium ${textClass}`}>
                  {selectedLevel || 'Experience'}
                </span>
                <ChevronDown size={16} />
              </button>
              <div className={`absolute top-full left-0 mt-2 w-48 rounded-lg shadow-xl border ${borderClass} ${cardBgClass} opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all z-50`}>
                <button
                  onClick={() => setSelectedLevel('')}
                  className={`block w-full text-left px-4 py-2 text-sm ${textClass} hover:bg-[#00A8CC] hover:text-white transition-colors`}
                >
                  All Levels
                </button>
                {levels.map((level) => (
                  <button
                    key={level}
                    onClick={() => setSelectedLevel(level)}
                    className={`block w-full text-left px-4 py-2 text-sm ${textClass} hover:bg-[#00A8CC] hover:text-white transition-colors ${
                      selectedLevel === level ? 'bg-[#00A8CC] text-white' : ''
                    }`}
                  >
                    {level}
                  </button>
                ))}
              </div>
            </div>

            {/* Rating Filter */}
            <div className="relative group">
              <button className={`flex items-center gap-2 px-4 py-2 rounded-lg border ${borderClass} ${cardBgClass} hover:border-[#00A8CC] transition-all`}>
                <span className={`text-sm font-medium ${textClass}`}>
                  {selectedRating ? `${selectedRating}+ ⭐` : 'Rating'}
                </span>
                <ChevronDown size={16} />
              </button>
              <div className={`absolute top-full left-0 mt-2 w-48 rounded-lg shadow-xl border ${borderClass} ${cardBgClass} opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all z-50`}>
                <button
                  onClick={() => setSelectedRating('')}
                  className={`block w-full text-left px-4 py-2 text-sm ${textClass} hover:bg-[#00A8CC] hover:text-white transition-colors`}
                >
                  All Ratings
                </button>
                {['4.5', '4.7', '4.9'].map((rating) => (
                  <button
                    key={rating}
                    onClick={() => setSelectedRating(rating)}
                    className={`block w-full text-left px-4 py-2 text-sm ${textClass} hover:bg-[#00A8CC] hover:text-white transition-colors ${
                      selectedRating === rating ? 'bg-[#00A8CC] text-white' : ''
                    }`}
                  >
                    {rating}+ ⭐
                  </button>
                ))}
              </div>
            </div>

            {hasActiveFilters && (
              <button
                onClick={clearFilters}
                className="flex items-center gap-2 px-4 py-2 rounded-lg bg-red-50 text-red-600 hover:bg-red-100 transition-all text-sm font-medium"
              >
                <X size={16} />
                Clear
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Results */}
      <main className="max-w-7xl mx-auto px-6 py-8">
        <div className={`mb-6 text-sm font-medium ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
          Showing {filteredEngineers.length} of {engineers.length} engineers
        </div>

        {filteredEngineers.length > 0 ? (
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {filteredEngineers.map((engineer, index) => (
              <div
                key={engineer.id}
                className={`${cardBgClass} border ${borderClass} rounded-xl p-6 hover:shadow-lg hover:border-[#00A8CC] transition-all duration-300 transform hover:scale-105 hover:-translate-y-1`}
                style={{ animationDelay: `${index * 50}ms` }}
              >
                {/* Header */}
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className="text-4xl">{engineer.avatar}</div>
                    <div>
                      <h3 className={`font-bold text-lg ${textClass}`}>
                        {engineer.name}
                      </h3>
                      <p
                        className="text-sm font-semibold"
                        style={{ color: '#00A8CC' }}
                      >
                        {engineer.specialty}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Rating */}
                <div className="flex items-center gap-2 mb-4">
                  <div className="flex items-center gap-1">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        size={16}
                        className={i < Math.floor(engineer.rating) ? 'fill-[#00A8CC] text-[#00A8CC]' : 'text-gray-300'}
                      />
                    ))}
                  </div>
                  <span className={`text-sm font-semibold ${textClass}`}>
                    {engineer.rating}
                  </span>
                  <span className={`text-xs ${darkMode ? 'text-gray-500' : 'text-gray-500'}`}>
                    ({engineer.reviews})
                  </span>
                </div>

                {/* Experience */}
                <div className="mb-4">
                  <span
                    className="inline-block px-3 py-1 rounded-full text-xs font-semibold text-white"
                    style={{ backgroundColor: '#1A2B4A' }}
                  >
                    {engineer.experience}
                  </span>
                </div>

                {/* Skills */}
                <div className="mb-4">
                  <p className={`text-xs font-semibold mb-2 ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                    SKILLS
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {engineer.skills.map((skill) => (
                      <span
                        key={skill}
                        className="px-2.5 py-1 rounded-md text-xs font-medium text-white"
                        style={{ backgroundColor: '#00A8CC' }}
                      >
                        {skill}
                      </span>
                    ))}
                  </div>
                </div>

                {/* CTA */}
                <button
                  className="w-full mt-4 py-2 rounded-lg font-semibold text-white transition-all hover:shadow-lg"
                  style={{ backgroundColor: '#1A2B4A' }}
                  onMouseEnter={(e) => (e.target.style.backgroundColor = '#00A8CC')}
                  onMouseLeave={(e) => (e.target.style.backgroundColor = '#1A2B4A')}
                >
                  View Profile
                </button>
              </div>
            ))}
          </div>
        ) : (
          <div className={`text-center py-16 ${cardBgClass} rounded-xl border ${borderClass}`}>
            <p className={`text-lg font-medium ${textClass}`}>
              No engineers found matching your criteria
            </p>
            <p className={`text-sm mt-2 ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
              Try adjusting your filters or search terms
            </p>
          </div>
        )}
      </main>
    </div>
  );
}