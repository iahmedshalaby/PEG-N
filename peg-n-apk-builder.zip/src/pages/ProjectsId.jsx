import React, { useState, useMemo } from 'react';

export default function ProjectDetails({ id = 'PRJ-001' }) {
  const [darkMode, setDarkMode] = useState(false);

  const project = useMemo(
    () => ({
      id,
      name: 'Project Atlas',
      summary:
        'A comprehensive initiative to modernize our core platform, integrating real-time analytics, modular microservices, and a mobile-friendly UI. The project scope includes task breakdown, timeline tracking, team assignments, progress visualization, and deliverable management.',
      startDate: '2026-04-01',
      endDate: '2026-10-31',
      status: 'In Progress',
      progress: 62,
      team: [
        { name: 'Alex Kim', role: 'Product Manager' },
        { name: 'Priya Singh', role: 'Tech Lead' },
        { name: 'Liam Chen', role: 'Backend Engineer' },
        { name: 'Sara Gomez', role: 'UX Designer' },
        { name: 'Noah Patel', role: 'QA Engineer' },
      ],
      tasks: [
        { id: 'T1', title: 'Kickoff & Requirements', owner: 'Alex Kim', progress: 100, due: '2026-04-10' },
        { id: 'T2', title: 'Architecture & Tech Stack', owner: 'Priya Singh', progress: 60, due: '2026-04-25' },
        { id: 'T3', title: 'API Design & Contracts', owner: 'Liam Chen', progress: 40, due: '2026-05-15' },
        { id: 'T4', title: 'Frontend Framework & UI Components', owner: 'Sara Gomez', progress: 55, due: '2026-06-20' },
        { id: 'T5', title: 'Integrations & Testing', owner: 'Noah Patel', progress: 25, due: '2026-07-30' },
      ],
      deliverables: [
        { name: 'Requirements Document', due: '2026-04-10', status: 'Approved' },
        { name: 'System Architecture Diagram', due: '2026-04-28', status: 'In Review' },
        { name: 'API Contracts', due: '2026-05-16', status: 'Planned' },
        { name: 'UI Kit & Prototypes', due: '2026-06-25', status: 'Planned' },
      ],
      timeline: [
        { phase: 'Initiation', start: '2026-04-01', end: '2026-04-15', progress: 100 },
        { phase: 'Design', start: '2026-04-16', end: '2026-05-15', progress: 60 },
        { phase: 'Implementation', start: '2026-05-16', end: '2026-09-15', progress: 40 },
        { phase: 'QA & Launch', start: '2026-09-16', end: '2026-10-31', progress: 20 },
      ],
    }),
    [id]
  );

  const overallProgress = project.progress;

  function Avatar({ name }) {
    const initials = name
      .split(' ')
      .map((n) => n[0])
      .slice(0, 2)
      .join('')
      .toUpperCase();
    return (
      <div
        className="w-9 h-9 rounded-full bg-gradient-to-br from-[#0F172A] to-[#334155] flex items-center justify-center text-white text-xs font-semibold"
        title={name}
      >
        {initials}
      </div>
    );
  }

  return (
    <div className={darkMode ? 'dark' : ''}>
      <div className="min-h-screen bg-white dark:bg-gray-900 transition-colors duration-300 font-sans">
        <div className="max-w-7xl mx-auto px-4 py-6">
          {/* Header */}
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <button
                className="p-2 rounded-md bg-[#1A2B4A] text-white hover:bg-[#12224B] transition-colors"
                onClick={() => window.history.length ? window.history.back() : null}
                aria-label="Back"
              >
                ◀
              </button>
              <h1 className="text-2xl font-semibold text-gray-900 dark:text-gray-100">
                Project Details
              </h1>
              <span className="px-3 py-1 text-sm rounded-full bg-[#E6F0FA] text-[#0A3A62] dark:bg-[#1E3A8A] dark:text-white">
                {project.name} (ID: {project.id})
              </span>
            </div>
            <button
              onClick={() => setDarkMode((m) => !m)}
              className="px-3 py-2 rounded-md border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm text-gray-800 dark:text-gray-100 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
            >
              {darkMode ? 'Light Theme' : 'Dark Theme'}
            </button>
          </div>

          {/* Overview + Team + Timeline grid */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Left: Overview */}
            <section className="lg:col-span-7 w-full">
              <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md border border-gray-200 dark:border-gray-700 p-5 mb-6">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-xl font-semibold text-gray-800 dark:text-gray-100">Overview</h2>
                  <span className="px-3 py-1 text-sm rounded-full bg-[#E6F0FA] text-[#0A3A62] dark:bg-[#1E3A8A] dark:text-white">
                    Status: {project.status}
                  </span>
                </div>
                <p className="text-sm text-gray-700 dark:text-gray-300 mb-4">{project.summary}</p>

                {/* Overall Progress */}
                <div className="mb-4">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-sm text-gray-600 dark:text-gray-300">Overall Progress</span>
                    <span className="text-sm font-semibold text-[#1A2B4A] dark:text-[#93C5FD]">{overallProgress}%</span>
                  </div>
                  <div className="h-3 rounded-full bg-gray-200 dark:bg-gray-700 overflow-hidden">
                    <div
                      className="h-full bg-[#00A8CC] transition-all duration-500"
                      style={{ width: `${overallProgress}%` }}
                    />
                  </div>
                </div>

                {/* Timeline chips */}
                <div className="flex flex-wrap items-center gap-2">
                  {project.timeline.map((t) => (
                    <span
                      key={t.phase}
                      className="flex items-center gap-2 px-3 py-1 rounded-full bg-gray-100 dark:bg-gray-700 text-xs text-gray-700 dark:text-gray-200"
                    >
                      <span
                        className="w-2 h-2 rounded-full"
                        style={{
                          background: '#00A8CC',
                          display: 'inline-block',
                          boxShadow: '0 0 0 2px rgba(0,0,0,.04)',
                        }}
                      />
                      {t.phase} • {t.start} to {t.end}
                    </span>
                  ))}
                </div>
              </div>
            </section>

            {/* Right: Team & Deliverables */}
            <aside className="lg:col-span-5 space-y-6">
              {/* Team Card */}
              <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md border border-gray-200 dark:border-gray-700 p-5">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-lg font-semibold text-gray-800 dark:text-gray-100">Assigned Team</h3>
                  <span className="text-xs text-gray-500">{project.team.length} members</span>
                </div>
                <div className="flex flex-wrap items-center gap-3">
                  {project.team.map((member) => (
                    <div key={member.name} className="flex items-center gap-2">
                      <Avatar name={member.name} />
                      <div className="flex flex-col">
                        <span className="text-sm font-semibold text-gray-700 dark:text-gray-100">
                          {member.name}
                        </span>
                        <span className="text-xs text-gray-500 dark:text-gray-300">{member.role}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Deliverables Card */}
              <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md border border-gray-200 dark:border-gray-700 p-5">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-lg font-semibold text-gray-800 dark:text-gray-100">Deliverables</h3>
                  <span className="text-xs text-gray-500">{project.deliverables.length} items</span>
                </div>
                <ul className="space-y-2">
                  {project.deliverables.map((d) => (
                    <li key={d.name} className="flex justify-between items-center">
                      <span className="text-sm text-gray-700 dark:text-gray-200">{d.name}</span>
                      <span className="text-xs px-2 py-1 rounded-full bg-[#E6F0FA] text-[#0A3A62] dark:bg-[#1E3A8A] dark:text-white">
                        Due {d.due} • {d.status}
                      </span>
                    </li>
                  ))}
                </ul>
              </div>
            </aside>
          </div>

          {/* Task Breakdown */}
          <section className="mt-6">
            <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md border border-gray-200 dark:border-gray-700 p-5">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-lg font-semibold text-gray-800 dark:text-gray-100">Task Breakdown</h3>
                <span className="text-xs text-gray-500">{project.tasks.length} tasks</span>
              </div>

              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                  <thead className="bg-gray-50 dark:bg-gray-700">
                    <tr>
                      <th className="px-4 py-2 text-left text-xs font-semibold text-gray-600 dark:text-gray-200 uppercase">
                        Task
                      </th>
                      <th className="px-4 py-2 text-left text-xs font-semibold text-gray-600 dark:text-gray-200 uppercase">
                        Owner
                      </th>
                      <th className="px-4 py-2 text-left text-xs font-semibold text-gray-600 dark:text-gray-200 uppercase">
                        Due
                      </th>
                      <th className="px-4 py-2 text-left text-xs font-semibold text-gray-600 dark:text-gray-200 uppercase">
                        Progress
                      </th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
                    {project.tasks.map((t) => (
                      <tr key={t.id}>
                        <td className="px-4 py-3">
                          <div className="flex items-center gap-2">
                            <span className="text-sm font-medium text-gray-800 dark:text-gray-100">{t.title}</span>
                          </div>
                        </td>
                        <td className="px-4 py-3">
                          <span className="inline-flex items-center px-2 py-1 rounded-full text-xs bg-[#E6F0FA] text-[#0A3A62] dark:bg-[#1E3A8A] dark:text-white">
                            {t.owner}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-sm text-gray-600 dark:text-gray-300">
                          {t.due}
                        </td>
                        <td className="px-4 py-3">
                          <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-3 overflow-hidden">
                            <div
                              className="h-full bg-[#00A8CC] transition-all duration-500"
                              style={{ width: `${t.progress}%` }}
                              aria-valuenow={t.progress}
                              aria-valuemin={0}
                              aria-valuemax={100}
                            />
                          </div>
                          <span className="text-xs text-gray-500 dark:text-gray-300 mt-1 block">
                            {t.progress}%
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </section>
        </div>
      </div>
    </div>
  );
}