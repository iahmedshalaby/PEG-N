import React, { useEffect, useMemo, useRef, useState } from 'react';

export default function MessagingCenter() {
  const [darkMode, setDarkMode] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [activeConvo, setActiveConvo] = useState('c1');
  const [draft, setDraft] = useState('');
  const chatRef = useRef(null);

  const conversations = useMemo(
    () => [
      { id: 'c1', name: 'Alex Kim', role: 'Engineer', lastMessage: 'Code baseline merged', time: '2m', unread: 1, avatar: 'AK' },
      { id: 'c2', name: 'Priya Sharma', role: 'Project Manager', lastMessage: 'Sprint planning ready', time: '10m', unread: 0, avatar: 'PS' },
      { id: 'c3', name: 'Admin Team', role: 'Administrator', lastMessage: 'Policy updated', time: '1h', unread: 0, avatar: 'AT' },
    ],
    []
  );

  const initialMessages = {
    c1: [
      { from: 'engineer', text: 'Hey, can you review the deployment script?', time: '09:15' },
      { from: 'you', text: 'Sure, I will check it in a bit.', time: '09:17' },
    ],
    c2: [
      { from: 'manager', text: 'Please share the latest sprint progress.', time: '09:20' },
      { from: 'you', text: 'Working on the backlog refinement now.', time: '09:22' },
    ],
    c3: [
      { from: 'administrator', text: 'Policy update pushed to docs.', time: '08:45' },
    ],
  };

  const [messages, setMessages] = useState(initialMessages);

  // Apply dark mode class to document
  useEffect(() => {
    document.documentElement.classList.toggle('dark', darkMode);
  }, [darkMode]);

  // Ensure chat scrolls to bottom on update
  useEffect(() => {
    if (chatRef.current) {
      chatRef.current.scrollTop = chatRef.current.scrollHeight;
    }
  }, [messages, activeConvo]);

  const activeConversation = conversations.find((c) => c.id === activeConvo) || conversations[0];

  function sendMessage(e) {
    e?.preventDefault();
    const text = draft.trim();
    if (!text) return;

    const newMsg = { from: 'you', text, time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) };

    setMessages((prev) => ({
      ...prev,
      [activeConvo]: [...(prev[activeConvo] || []), newMsg],
    }));
    setDraft('');

    // Simulated automated reply for realism
    setTimeout(() => {
      const reply = {
        from: 'engineer',
        text: 'Acknowledged. I’ll ping you with an update soon.',
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => ({
        ...prev,
        [activeConvo]: [...(prev[activeConvo] || []), reply],
      }));
    }, 900);
  }

  // Light responsive helper for mobile
  const shouldHideSidebarOnMobile = () => typeof window !== 'undefined' && window.innerWidth < 768;

  useEffect(() => {
    const onResize = () => {
      if (window.innerWidth >= 768) {
        setSidebarOpen(true);
      }
    };
    window.addEventListener('resize', onResize);
    return () => window.removeEventListener('resize', onResize);
  }, []);

  return (
    <div className="min-h-screen bg-white dark:bg-[#0b1220] text-gray-800 dark:text-gray-100 font-sans">
      <header className="bg-[#1A2B4A] text-white shadow-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between h-14 gap-3">
          <div className="flex items-center gap-3">
            <button
              aria-label="Toggle sidebar"
              className="md:hidden p-2 rounded-md bg-white/10 hover:bg-white/20 text-white"
              onClick={() => setSidebarOpen((s) => !s)}
              style={{ backdropFilter: 'blur(4px)' }}
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              </svg>
            </button>
            <span className="text-lg font-semibold tracking-tight" style={{ color: '#FFFFFF' }}>
              Messaging Center
            </span>
          </div>

          <div className="hidden md:flex items-center gap-3">
            <span className="text-sm text-white/90">Real-time messaging for engineers, PMs, and admins</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setDarkMode((d) => !d)}
              className="bg-white/10 hover:bg-white/20 text-white text-sm px-3 py-2 rounded-md transition-colors duration-200"
            >
              {darkMode ? 'Light Mode' : 'Dark Mode'}
            </button>
            <div className="hidden md:flex items-center justify-center w-9 h-9 rounded-full bg-teal-500/20 border border-teal-400 text-teal-200">
              <span className="text-xs font-semibold" style={{ color: '#00A8CC' }}>
                MC
              </span>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
        <div className="grid grid-cols-12 gap-4 h-[calc(100vh-56px)]">
          {/* Conversations Panel (Left) */}
          <section
            aria-label="Conversations"
            className={`bg-white dark:bg-[#0b1220] rounded-lg shadow overflow-hidden
                        ${sidebarOpen ? 'block' : 'hidden'}
                        md:block md:col-span-4 lg:col-span-3`}
          >
            <div className="flex items-center justify-between px-4 py-3 border-b border-gray-200 dark:border-gray-800">
              <div className="flex items-center gap-2">
                <span className="w-3 h-3 rounded-full bg-teal-500" />
                <h2 className="text-sm font-semibold" style={{ color: '#1A2B4A' }}>
                  Conversations
                </h2>
              </div>
              <span className="text-xs text-gray-500">{conversations.length} active</span>
            </div>

            <div className="p-3 space-y-2 overflow-y-auto h-[calc(100vh-56px)]">
              {conversations.map((c) => {
                const unread = c.unread > 0;
                return (
                  <button
                    key={c.id}
                    onClick={() => {
                      setActiveConvo(c.id);
                      if (shouldHideSidebarOnMobile()) setSidebarOpen(false);
                    }}
                    className={`w-full text-left rounded-lg px-3 py-2 hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors
                                ${activeConvo === c.id ? 'bg-gray-100 dark:bg-gray-800' : ''}`}
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-full bg-[#e8eefc] text-[#1A2B4A] flex items-center justify-center font-semibold">
                        {c.avatar}
                      </div>
                      <div className="flex-1 text-left">
                        <div className="text-sm font-medium">{c.name}</div>
                        <div className="text-xs text-gray-500 truncate" style={{ maxWidth: '210px' }}>
                          {c.lastMessage}
                        </div>
                      </div>
                      <div className="text-xs text-gray-500">{c.time}</div>
                    </div>
                    {unread ? (
                      <span className="sr-only">Unread messages</span>
                    ) : null}
                    {unread ? (
                      <span className="inline-flex items-center justify-center px-2 py-1 text-xs font-semibold rounded-full bg-teal-200 text-teal-800 float-right">
                        {c.unread}
                      </span>
                    ) : null}
                  </button>
                );
              })}
            </div>
          </section>

          {/* Chat Panel (Center) */}
          <section className="bg-white dark:bg-[#0b1220] rounded-lg shadow col-span-12 md:col-span-8 lg:col-span-6 flex flex-col">
            <div className="flex items-center justify-between px-4 py-3 border-b border-gray-200 dark:border-gray-800">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-full bg-[#e8eefc] text-[#1A2B4A] flex items-center justify-center font-semibold">
                  {activeConversation?.avatar}
                </div>
                <div>
                  <div className="text-sm font-medium">{activeConversation?.name}</div>
                  <div className="text-xs text-gray-500">{activeConversation?.role}</div>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-xs text-gray-500 hidden sm:block">Last active: {conversations.find(c => c.id === activeConvo)?.time || '—'}</span>
              </div>
            </div>

            <div ref={chatRef} className="flex-1 overflow-y-auto p-4 space-y-2" style={{ minHeight: 0 }}>
              {(messages[activeConvo] || []).map((m, idx) => (
                <div key={idx} className={`flex ${m.from === 'you' ? 'justify-end' : 'justify-start'}`}>
                  <div
                    className={`max-w-md px-4 py-2 rounded-lg shadow
                                ${m.from === 'you' ? 'bg-[#1A2B4A] text-white' : 'bg-[#EAF0FF] text-gray-800'}`}
                    style={{
                      borderTopRightRadius: m.from === 'you' ? 0 : 12,
                      borderTopLeftRadius: m.from === 'you' ? 12 : 0,
                    }}
                  >
                    <div className="text-sm">{m.text}</div>
                    <div className="text-xs text-gray-500 text-right mt-1" style={{ opacity: 0.8 }}>
                      {m.time}
                    </div>
                  </div>
                </div>
              ))}
              {(!messages[activeConvo] || messages[activeConvo].length === 0) && (
                <div className="text-sm text-gray-500 mt-6">No messages yet. Start the conversation.</div>
              )}
            </div>

            <form onSubmit={sendMessage} className="border-t border-gray-200 dark:border-gray-800 p-4 bg-white dark:bg-[#0b1220]">
              <div className="flex items-center gap-2">
                <input
                  value={draft}
                  onChange={(e) => setDraft(e.target.value)}
                  placeholder="Type a message..."
                  className="flex-1 px-4 py-2 rounded-full border border-gray-300 dark:border-gray-700 bg-white dark:bg-[#111827] text-gray-800 dark:text-gray-100 focus:outline-none focus:ring-2 focus:ring-[#00A8CC]"
                />
                <button
                  type="submit"
                  className="px-4 py-2 rounded-full bg-[#1A2B4A] text-white hover:bg-[#21315f] transition-colors"
                >
                  Send
                </button>
              </div>
            </form>
          </section>

          {/* Channel Details Panel (Right) */}
          <aside className="bg-white dark:bg-[#0b1220] rounded-lg shadow overflow-hidden col-span-12 md:col-span-4 lg:col-span-3">
            <div className="px-4 py-3 border-b border-gray-200 dark:border-gray-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="w-5 h-5 rounded bg-teal-500" />
                <span className="text-sm font-semibold" style={{ color: '#1A2B4A' }}>
                  Channel Details
                </span>
              </div>
              <span className="text-xs text-gray-500">Live</span>
            </div>

            <div className="p-4 space-y-4">
              <div className="bg-gray-50 dark:bg-gray-900 rounded-lg p-4 border border-gray-200 dark:border-gray-800">
                <div className="text-sm font-medium mb-1" style={{ color: '#1A2B4A' }}>
                  Participants
                </div>
                <div className="flex items-center gap-2 flex-wrap">
                  {conversations.map((c) => (
                    <div key={c.id} className="flex items-center gap-2 px-2 py-1 rounded-full bg-gray-100 dark:bg-gray-800 text-xs">
                      <span className="w-6 h-6 rounded-full bg-[#e8eefc] flex items-center justify-center text-xs">{c.avatar}</span>
                      <span className="truncate" style={{ maxWidth: 80 }}>
                        {c.name.split(' ')[0]}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-gray-50 dark:bg-gray-900 rounded-lg p-4 border border-gray-200 dark:border-gray-800">
                <div className="text-sm font-medium mb-2" style={{ color: '#1A2B4A' }}>
                  Activity
                </div>
                <ul className="text-xs text-gray-700 dark:text-gray-200 space-y-1">
                  <li>Messages today: 42</li>
                  <li>Online status: 3/5</li>
                  <li>Last update: 2m ago</li>
                </ul>
              </div>

              <div className="flex gap-2 pt-2 border-t border-gray-200 dark:border-gray-800">
                <button className="flex-1 px-3 py-2 rounded-md bg-teal-100 text-teal-800 text-sm">
                  Export Chat
                </button>
                <button className="flex-1 px-3 py-2 rounded-md bg-gray-100 dark:bg-gray-800 text-sm">
                  Clear
                </button>
              </div>
            </div>
          </aside>
        </div>
      </main>
    </div>
  );
}