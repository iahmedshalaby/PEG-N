'use client';

import React, { useState } from 'react';
import { TrendingUp, Users, Zap, BarChart3, ChevronRight, Bell, Settings, Menu, X } from 'lucide-react';

export default function Dashboard() {
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const bgPrimary = isDarkMode ? 'bg-slate-900' : 'bg-white';
  const bgSecondary = isDarkMode ? 'bg-slate-800' : 'bg-slate-50';
  const textPrimary = isDarkMode ? 'text-white' : 'text-slate-900';
  const textSecondary = isDarkMode ? 'text-slate-400' : 'text-slate-600';
  const borderColor = isDarkMode ? 'border-slate-700' : 'border-slate-200';

  const stats = [
    { label: 'Active Projects', value: '24', change: '+12%', icon: Zap, color: 'from-blue-500 to-cyan-500' },
    { label: 'Team Members', value: '156', change: '+8%', icon: Users, color: 'from-purple-500 to-pink-500' },
    { label: 'Network Performance', value: '98.2%', change: '+2.1%', icon: TrendingUp, color: 'from-green-500 to-emerald-500' },
    { label: 'Data Processed', value: '2.4TB', change: '+34%', icon: BarChart3, color: 'from-orange-500 to-red-500' },
  ];

  const projects = [
    { id: 1, name: 'Cloud Infrastructure', status: 'Active', progress: 87, team: 8 },
    { id: 2, name: 'API Gateway Optimization', status: 'In Progress', progress: 62, team: 5 },
    { id: 3, name: 'Security Audit 2026', status: 'Active', progress: 45, team: 6 },
    { id: 4, name: 'Database Migration', status: 'Pending', progress: 23, team: 4 },
  ];

  const activities = [
    { user: 'Sarah Mitchell', action: 'deployed new version', time: '2 hours ago', type: 'deployment' },
    { user: 'James Chen', action: 'reviewed pull request', time: '4 hours ago', type: 'review' },
    { user: 'Emma Rodriguez', action: 'created new dashboard', time: '6 hours ago', type: 'create' },
    { user: 'Alex Kumar', action: 'resolved critical issue', time: '8 hours ago', type: 'resolved' },
  ];

  return (
    <div className={`min-h-screen transition-colors duration-300 ${isDarkMode ? 'bg-slate-950' : 'bg-gray-50'}`}>
      {/* Header */}
      <header className={`${bgPrimary} border-b ${borderColor} sticky top-0 z-50 transition-colors duration-300`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center">
                <span className="text-white font-bold text-lg">K</span>
              </div>
              <h1 className={`text-2xl font-bold ${textPrimary}`}>Kiro Dashboard</h1>
            </div>
            <div className="flex items-center gap-4">
              <button
                onClick={() => setIsDarkMode(!isDarkMode)}
                className={`p-2 rounded-lg transition-colors duration-200 ${bgSecondary} hover:opacity-80`}
              >
                {isDarkMode ? '☀️' : '🌙'}
              </button>
              <button className={`p-2 rounded-lg transition-colors duration-200 ${bgSecondary} hover:opacity-80`}>
                <Bell size={20} className={textSecondary} />
              </button>
              <button className={`p-2 rounded-lg transition-colors duration-200 ${bgSecondary} hover:opacity-80`}>
                <Settings size={20} className={textSecondary} />
              </button>
              <button
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                className="md:hidden p-2 rounded-lg transition-colors duration-200"
              >
                {isMobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h2 className={`text-3xl font-bold ${textPrimary} mb-2`}>Welcome back, Sarah</h2>
          <p className={textSecondary}>Here's what's happening with your network today</p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat, idx) => {
            const Icon = stat.icon;
            return (
              <div
                key={idx}
                className={`${bgPrimary} rounded-xl p-6 border ${borderColor} hover:shadow-lg transition-all duration-300 cursor-pointer hover:scale-105 group`}
              >
                <div className="flex justify-between items-start mb-4">
                  <div className={`w-12 h-12 rounded-lg bg-gradient-to-br ${stat.color} p-3 text-white group-hover:shadow-lg transition-shadow`}>
                    <Icon size={24} />
                  </div>
                  <span className="text-green-500 text-sm font-semibold">{stat.change}</span>
                </div>
                <h3 className={`text-sm font-medium ${textSecondary} mb-1`}>{stat.label}</h3>
                <p className={`text-3xl font-bold ${textPrimary}`}>{stat.value}</p>
              </div>
            );
          })}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Projects Section */}
          <div className="lg:col-span-2">
            <div className={`${bgPrimary} rounded-xl border ${borderColor} overflow-hidden transition-colors duration-300`}>
              <div className="px-6 py-4 border-b border-slate-200 dark:border-slate-700 flex justify-between items-center">
                <h3 className={`text-lg font-bold ${textPrimary}`}>Active Projects</h3>
                <button className="text-cyan-500 hover:text-cyan-600 flex items-center gap-1 text-sm font-medium">
                  View All <ChevronRight size={16} />
                </button>
              </div>
              <div className="divide-y divide-slate-200 dark:divide-slate-700">
                {projects.map((project) => (
                  <div key={project.id} className={`px-6 py-4 hover:${bgSecondary} transition-colors duration-200 cursor-pointer group`}>
                    <div className="flex justify-between items-start mb-3">
                      <div>
                        <h4 className={`font-semibold ${textPrimary} group-hover:text-cyan-500 transition-colors`}>{project.name}</h4>
                        <p className={`text-sm ${textSecondary}`}>
                          {project.team} team members • <span className="text-cyan-500">{project.status}</span>
                        </p>
                      </div>
                    </div>
                    <div className="w-full bg-slate-200 dark:bg-slate-700 rounded-full h-2">
                      <div
                        className="bg-gradient-to-r from-cyan-500 to-blue-600 h-2 rounded-full transition-all duration-500"
                        style={{ width: `${project.progress}%` }}
                      ></div>
                    </div>
                    <p className={`text-xs ${textSecondary} mt-2`}>{project.progress}% Complete</p>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Team Activity */}
          <div className={`${bgPrimary} rounded-xl border ${borderColor} overflow-hidden transition-colors duration-300`}>
            <div className="px-6 py-4 border-b border-slate-200 dark:border-slate-700">
              <h3 className={`text-lg font-bold ${textPrimary}`}>Team Activity</h3>
            </div>
            <div className="divide-y divide-slate-200 dark:divide-slate-700">
              {activities.map((activity, idx) => (
                <div key={idx} className="px-6 py-4 hover:opacity-75 transition-opacity duration-200">
                  <p className={`text-sm font-medium ${textPrimary}`}>{activity.user}</p>
                  <p className={`text-sm ${textSecondary} mt-1`}>{activity.action}</p>
                  <p className={`text-xs ${textSecondary} mt-2`}>{activity.time}</p>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Performance Chart Section */}
        <div className={`${bgPrimary} rounded-xl border ${borderColor} p-6 mt-8 transition-colors duration-300`}>
          <h3 className={`text-lg font-bold ${textPrimary} mb-4`}>Network Performance</h3>
          <div className="h-64 flex items-end justify-between gap-4">
            {[65, 78, 72, 85, 92, 88, 95, 89, 94, 87, 91, 96].map((value, idx) => (
              <div
                key={idx}
                className="flex-1 bg-gradient-to-t from-cyan-500 to-blue-600 rounded-t-lg hover:opacity-80 transition-opacity cursor-pointer group"
                style={{ height: `${value}%` }}
              >
                <div className="opacity-0 group-hover:opacity-100 transition-opacity text-white text-xs font-bold flex justify-center items-end h-full pb-2">
                  {value}%
                </div>
              </div>
            ))}
          </div>
          <div className="flex justify-between mt-4 text-xs text-slate-500">
            <span>Jan</span>
            <span>Feb</span>
            <span>Mar</span>
            <span>Apr</span>
            <span>May</span>
            <span>Jun</span>
            <span>Jul</span>
            <span>Aug</span>
            <span>Sep</span>
            <span>Oct</span>
            <span>Nov</span>
            <span>Dec</span>
          </div>
        </div>
      </main>
    </div>
  );
}