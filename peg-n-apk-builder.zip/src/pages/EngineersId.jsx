'use client';

import React, { useState } from 'react';
import { Star, MapPin, Calendar, Award, Briefcase, Users, Download, MessageSquare, Heart } from 'lucide-react';

export default function EngineerProfile() {
  const [isFavorite, setIsFavorite] = useState(false);
  const [activeTab, setActiveTab] = useState('portfolio');
  const [darkMode, setDarkMode] = useState(false);

  const engineer = {
    id: 1,
    name: 'Sarah Chen',
    title: 'Senior Full-Stack Engineer',
    location: 'San Francisco, CA',
    rating: 4.9,
    reviews: 127,
    hourlyRate: '$85/hr',
    availability: 'Available',
    bio: 'Experienced full-stack engineer with 8+ years building scalable web applications. Specialized in React, Node.js, and cloud architecture. Passionate about clean code and mentoring junior developers.',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400&h=400&fit=crop',
    coverImage: 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=1200&h=300&fit=crop',
    skills: ['React', 'Node.js', 'TypeScript', 'PostgreSQL', 'AWS', 'Docker', 'GraphQL', 'System Design'],
    certifications: [
      { name: 'AWS Solutions Architect', issuer: 'Amazon Web Services', date: '2023' },
      { name: 'Kubernetes Administrator', issuer: 'Linux Foundation', date: '2022' },
      { name: 'Google Cloud Professional', issuer: 'Google Cloud', date: '2021' }
    ],
    portfolio: [
      { title: 'E-Commerce Platform', description: 'Built scalable marketplace with 50k+ daily users', tech: 'React, Node.js, PostgreSQL', link: '#' },
      { title: 'Real-Time Analytics Dashboard', description: 'Live data visualization processing 1M+ events/day', tech: 'React, WebSocket, Kafka', link: '#' },
      { title: 'Mobile App Backend', description: 'RESTful API serving iOS and Android applications', tech: 'Node.js, Express, MongoDB', link: '#' }
    ],
    reviews: [
      { author: 'John Smith', company: 'TechCorp', rating: 5, text: 'Exceptional work quality and communication. Delivered ahead of schedule.', date: '2024-01-15' },
      { author: 'Emma Davis', company: 'StartupXYZ', rating: 5, text: 'Sarah understood our requirements perfectly and provided valuable insights.', date: '2023-12-20' },
      { author: 'Michael Brown', company: 'Digital Solutions', rating: 4, text: 'Great technical skills. Very professional and reliable.', date: '2023-11-10' }
    ]
  };

  const bgColor = darkMode ? 'bg-slate-900' : 'bg-white';
  const textColor = darkMode ? 'text-white' : 'text-gray-900';
  const cardBg = darkMode ? 'bg-slate-800' : 'bg-gray-50';
  const borderColor = darkMode ? 'border-slate-700' : 'border-gray-200';

  return (
    <div className={`min-h-screen ${bgColor} ${textColor} transition-colors duration-300`}>
      {/* Header */}
      <div className="sticky top-0 z-40 border-b border-gray-200 dark:border-slate-700 bg-white dark:bg-slate-800">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <h1 className="text-2xl font-bold text-[#1A2B4A]">Engineer Profile</h1>
          <button
            onClick={() => setDarkMode(!darkMode)}
            className="px-4 py-2 rounded-lg bg-gray-200 dark:bg-slate-700 hover:bg-gray-300 dark:hover:bg-slate-600 transition-colors"
          >
            {darkMode ? '☀️' : '🌙'}
          </button>
        </div>
      </div>

      {/* Cover Image */}
      <div className="h-48 sm:h-64 overflow-hidden bg-gradient-to-r from-[#1A2B4A] to-[#00A8CC]">
        <img src={engineer.coverImage} alt="Cover" className="w-full h-full object-cover opacity-60" />
      </div>

      {/* Profile Section */}
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 pb-12">
        {/* Profile Header */}
        <div className="flex flex-col sm:flex-row gap-6 -mt-24 relative z-10 mb-8">
          <img
            src={engineer.avatar}
            alt={engineer.name}
            className="w-40 h-40 rounded-2xl border-4 border-white dark:border-slate-800 shadow-lg object-cover"
          />
          <div className="flex-1 pt-4 flex flex-col justify-between">
            <div>
              <h2 className="text-4xl font-bold mb-2">{engineer.name}</h2>
              <p className="text-xl text-[#00A8CC] font-semibold mb-3">{engineer.title}</p>
              <div className="flex flex-wrap gap-4 text-sm text-gray-600 dark:text-gray-400">
                <div className="flex items-center gap-1">
                  <MapPin size={16} />
                  {engineer.location}
                </div>
                <div className="flex items-center gap-1">
                  <Star size={16} className="fill-yellow-400 text-yellow-400" />
                  {engineer.rating} ({engineer.reviews} reviews)
                </div>
                <div className="flex items-center gap-1">
                  <Calendar size={16} />
                  {engineer.availability}
                </div>
              </div>
            </div>
            <div className="flex gap-3 flex-wrap">
              <button className="px-6 py-2 bg-[#1A2B4A] text-white rounded-lg hover:bg-[#0f1a2e] transition-colors font-semibold">
                <MessageSquare size={16} className="inline mr-2" />
                Contact
              </button>
              <button
                onClick={() => setIsFavorite(!isFavorite)}
                className={`px-6 py-2 rounded-lg border-2 transition-colors font-semibold ${
                  isFavorite
                    ? 'bg-red-50 dark:bg-red-900 border-red-300 dark:border-red-700 text-red-600'
                    : 'border-gray-300 dark:border-slate-600 hover:border-red-300 dark:hover:border-red-700'
                }`}
              >
                <Heart size={16} className={`inline mr-2 ${isFavorite ? 'fill-red-600' : ''}`} />
                {isFavorite ? 'Saved' : 'Save'}
              </button>
              <button className="px-6 py-2 border-2 border-gray-300 dark:border-slate-600 rounded-lg hover:bg-gray-100 dark:hover:bg-slate-700 transition-colors font-semibold">
                <Download size={16} className="inline mr-2" />
                Resume
              </button>
            </div>
          </div>
          <div className={`${cardBg} rounded-xl p-6 border border-gray-200 dark:border-slate-700 min-w-max`}>
            <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">Hourly Rate</p>
            <p className="text-3xl font-bold text-[#00A8CC] mb-4">{engineer.hourlyRate}</p>
            <button className="w-full px-4 py-2 bg-[#00A8CC] text-white rounded-lg hover:bg-[#0096b3] transition-colors font-semibold text-sm">
              Hire Now
            </button>
          </div>
        </div>

        {/* Bio Section */}
        <div className={`${cardBg} rounded-xl p-6 border border-gray-200 dark:border-slate-700 mb-8`}>
          <h3 className="text-lg font-bold mb-3">About</h3>
          <p className="text-gray-700 dark:text-gray-300 leading-relaxed">{engineer.bio}</p>
        </div>

        {/* Skills Section */}
        <div className={`${cardBg} rounded-xl p-6 border border-gray-200 dark:border-slate-700 mb-8`}>
          <h3 className="text-lg font-bold mb-4">Skills & Expertise</h3>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {engineer.skills.map((skill, idx) => (
              <div
                key={idx}
                className="px-4 py-2 bg-white dark:bg-slate-700 border border-[#00A8CC] rounded-lg text-center text-sm font-semibold text-[#00A8CC]"
              >
                {skill}
              </div>
            ))}
          </div>
        </div>

        {/* Tabs */}
        <div className="mb-8">
          <div className="flex gap-4 border-b border-gray-200 dark:border-slate-700 mb-6">
            {['portfolio', 'certifications', 'reviews'].map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`px-4 py-3 font-semibold transition-colors border-b-2 ${
                  activeTab === tab
                    ? 'border-[#00A8CC] text-[#00A8CC]'
                    : 'border-transparent text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-200'
                }`}
              >
                {tab.charAt(0).toUpperCase() + tab.slice(1)}
              </button>
            ))}
          </div>

          {/* Portfolio Tab */}
          {activeTab === 'portfolio' && (
            <div className="grid gap-4">
              {engineer.portfolio.map((project, idx) => (
                <div
                  key={idx}
                  className={`${cardBg} rounded-xl p-6 border border-gray-200 dark:border-slate-700 hover:shadow-lg transition-shadow`}
                >
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <h4 className="text-lg font-bold mb-1">{project.title}</h4>
                      <p className="text-gray-600 dark:text-gray-400 mb-3">{project.description}</p>
                    </div>
                    <Briefcase className="text-[#00A8CC]" size={24} />
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {project.tech.split(', ').map((tech, i) => (
                      <span key={i} className="px-3 py-1 bg-blue-100 dark:bg-blue-900 text-[#1A2B4A] dark:text-blue-200 text-xs rounded-full font-semibold">
                        {tech}
                      </span>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Certifications Tab */}
          {activeTab === 'certifications' && (
            <div className="grid gap-4">
              {engineer.certifications.map((cert, idx) => (
                <div
                  key={idx}
                  className={`${cardBg} rounded-xl p-6 border border-gray-200 dark:border-slate-700 flex items-start gap-4`}
                >
                  <Award className="text-[#00A8CC] flex-shrink-0 mt-1" size={24} />
                  <div className="flex-1">
                    <h4 className="text-lg font-bold mb-1">{cert.name}</h4>
                    <p className="text-gray-600 dark:text-gray-400">{cert.issuer}</p>
                    <p className="text-sm text-gray-500 dark:text-gray-500 mt-2">{cert.date}</p>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Reviews Tab */}
          {activeTab === 'reviews' && (
            <div className="grid gap-4">
              {engineer.reviews.map((review, idx) => (
                <div
                  key={idx}
                  className={`${cardBg} rounded-xl p-6 border border-gray-200 dark:border-slate-700`}
                >
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <p className="font-bold">{review.author}</p>
                      <p className="text-sm text-gray-600 dark:text-gray-400">{review.company}</p>
                    </div>
                    <div className="flex gap-1">
                      {[...Array(review.rating)].map((_, i) => (
                        <Star key={i} size={16} className="fill-yellow-400 text-yellow-400" />
                      ))}
                    </div>
                  </div>
                  <p className="text-gray-700 dark:text-gray-300 mb-3">{review.text}</p>
                  <p className="text-xs text-gray-500 dark:text-gray-500">{review.date}</p>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}