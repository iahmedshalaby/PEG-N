import React, { useMemo, useState, useEffect } from 'react';

export default function ProjectsBoard() {
  // Theme: light/dark
  const [dark, setDark] = useState(false);
  useEffect(() => {
    document.documentElement.classList.toggle('dark', dark);
  }, [dark]);

  // Sample teams
  const initialTeams = ['Frontend', 'Backend', 'Design', 'QA', 'Ops'];

  // Initial projects
  const [projects, setProjects] = useState([
    {
      id: 1,
      title: 'Revamp Analytics Dashboard',
      description: 'Overhaul KPI visualizations and real-time data streams.',
      status: 'In Progress',
      dueDate: '2026-06-25',
      progress: 60,
      teams: ['Frontend', 'Backend'],
    },
    {
      id: 2,
      title: 'Mobile App Push Notifications',
      description: 'Implement reliable delivery with user segmentation.',
      status: 'Not Started',
      dueDate: '2026-07-12',
      progress: 15,
      teams: ['Frontend', 'Ops'],
    },
    {
      id: 3,
      title: 'QA Automation Suite',
      description: 'Increase test coverage with end-to-end scenarios.',
      status: 'Done',
      dueDate: '2026-05-20',
      progress: 100,
      teams: ['QA', 'Design'],
    },
  ]);

  // UI state
  const [query, setQuery] = useState('');
  const [filterStatus, setFilterStatus] = useState('All');
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState(null); // project object or null
  const [selectedTeams, setSelectedTeams] = useState([]);
  const [form, setForm] = useState({
    title: '',
    description: '',
    status: 'Not Started',
    dueDate: '',
    progress: 0,
    teams: [],
  });

  // Derived
  const statuses = ['All', 'Not Started', 'In Progress', 'Review', 'Done'];

  const filteredProjects = useMemo(() => {
    return projects.filter((p) => {
      const matchesQuery =
        p.title.toLowerCase().includes(query.toLowerCase()) ||
        p.description.toLowerCase().includes(query.toLowerCase());
      const matchesStatus = filterStatus === 'All' || p.status === filterStatus;
      return matchesQuery && matchesStatus;
    });
  }, [projects, query, filterStatus]);

  // Helpers
  const resetForm = () => {
    setForm({
      title: '',
      description: '',
      status: 'Not Started',
      dueDate: '',
      progress: 0,
      teams: [],
    });
    setSelectedTeams([]);
  };

  const openCreate = () => {
    setEditing(null);
    resetForm();
    setModalOpen(true);
  };

  const openEdit = (p) => {
    setEditing(p);
    setForm({
      title: p.title,
      description: p.description,
      status: p.status,
      dueDate: p.dueDate,
      progress: p.progress,
      teams: p.teams,
    });
    setSelectedTeams(p.teams || []);
    setModalOpen(true);
  };

  const saveProject = () => {
    // Basic validation
    if (!form.title.trim()) return;

    const payload = {
      id: editing?.id ?? Date.now(),
      title: form.title.trim(),
      description: form.description.trim(),
      status: form.status,
      dueDate: form.dueDate,
      progress: Math.max(0, Math.min(100, Number(form.progress) || 0)),
      teams: selectedTeams.length ? selectedTeams : [],
    };

    if (editing) {
      // Update
      setProjects((prev) => prev.map((p) => (p.id === editing.id ? payload : p)));
    } else {
      // Create
      setProjects((prev) => [payload, ...prev]);
    }

    setModalOpen(false);
  };

  const toggleTeam = (t) => {
    setSelectedTeams((prev) =>
      prev.includes(t) ? prev.filter((x) => x !== t) : [...prev, t]
    );
  };

  // Ensure selectedTeams mirrors form. Keep in sync when editing
  useEffect(() => {
    setForm((f) => ({
      ...f,
      teams: selectedTeams,
    }));
  }, [selectedTeams]);

  // Formatting helpers
  const formatDate = (d) => {
    if (!d) return 'No due date';
    const dt = new Date(d);
    return dt.toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' });
  };

  const initialsFor = (name) => {
    if (!name) return '';
    const parts = name.trim().split(' ');
    const a = parts[0]?.charAt(0) ?? '';
    const b = parts[1]?.charAt(0) ?? '';
    return (a + b).toUpperCase();
  };

  const statusChip = (s) => {
    // Tailwind colors with rgba-like tones
    switch (s) {
      case 'Not Started':
        return 'bg-blue-100 text-blue-700';
      case 'In Progress':
        return 'bg-yellow-100 text-yellow-700';
      case 'Review':
        return 'bg-purple-100 text-purple-700';
      case 'Done':
        return 'bg-green-100 text-green-700';
      default:
        return 'bg-gray-100 text-gray-700';
    }
  };

  return (
    <div className="min-h-screen bg-white dark:bg-gray-900 transition-colors duration-300" aria-label="Projects Board root">
      {/* Theme root toggle and header */}
      <div className="px-6 py-4 md:px-8 bg-white dark:bg-gray-900 border-b border-gray-200 dark:border-gray-700">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="inline-block w-3 h-3 rounded-full" style={{ backgroundColor: '#1A2B4A' }} aria-label="brand-dot" />
            <h1 className="text-2xl font-semibold text-[#1A2B4A] dark:text-teal-300" style={{ fontFamily: 'Inter, ui-sans-serif' }}>
              Projects Board
            </h1>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setDark((d) => !d)}
              className="px-3 py-2 rounded-md border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-sm text-gray-700 dark:text-gray-100 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
              aria-label="Toggle dark mode"
            >
              {dark ? 'Light' : 'Dark'} mode
            </button>
            <button
              onClick={openCreate}
              className="group inline-flex items-center gap-2 px-4 py-2 rounded-md bg-[#1A2B4A] text-white hover:bg-[#10224A] transition-colors"
              aria-label="Create project"
            >
              <span className="group-hover:translate-x-0.5 transition-transform">＋</span>
              <span>New Project</span>
            </button>
          </div>
        </div>
      </div>

      {/* Content */}
      <main className="max-w-7xl mx-auto px-6 md:px-8 py-6">
        <section aria-label="Controls" className="mb-6">
          <div className="flex flex-col sm:flex-row items-stretch gap-3">
            <div className="flex-1">
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search projects..."
                className="w-full rounded-md border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-100 px-4 py-2 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-teal-300 transition-colors"
                aria-label="Search projects"
              />
            </div>
            <div className="w-48">
              <select
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value)}
                className="w-full rounded-md border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-100 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-teal-300 transition-colors"
                aria-label="Filter by status"
              >
                {statuses.map((s) => (
                  <option key={s} value={s}>{s}</option>
                ))}
              </select>
            </div>
          </div>
        </section>

        <section aria-label="Projects grid">
          <div className="grid gap-5" style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))' }}>
            {filteredProjects.map((p) => (
              <article key={p.id} className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl shadow-sm p-4 hover:shadow-md transition-shadow duration-200">
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100" style={{ fontFamily: 'Inter, ui-sans-serif' }}>
                      {p.title}
                    </h3>
                    <p className="mt-1 text-sm text-gray-500 dark:text-gray-300" style={{ fontFamily: 'Inter, ui-sans-serif' }}>
                      {p.description}
                    </p>
                  </div>
                  <button
                    onClick={() => openEdit(p)}
                    className="text-xs text-teal-600 dark:text-teal-300 hover:text-teal-700 dark:hover:text-teal-200 transition-colors"
                    aria-label="Edit project"
                  >
                    Edit
                  </button>
                </div>

                <div className="mt-3 flex items-center gap-2">
                  <span className={`px-2 py-1 rounded-full text-xs ${statusChip(p.status)}`} style={{ fontFamily: 'Inter, ui-sans-serif' }}>
                    {p.status}
                  </span>
                  <span className="text-xs text-gray-500 dark:text-gray-300" aria-label="Due date">
                    Due {formatDate(p.dueDate)}
                  </span>
                </div>

                <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2 mt-3 overflow-hidden" aria-label="Progress">
                  <div
                    className="h-2 rounded-full"
                    style={{
                      width: `${p.progress}%`,
                      backgroundColor: '#00A8CC',
                      transition: 'width 300ms ease',
                    }}
                  />
                </div>

                <div className="mt-3 flex items-center gap-2">
                  {p.teams.map((t) => (
                    <span
                      key={t}
                      className="w-8 h-8 inline-flex items-center justify-center rounded-full bg-teal-100 text-teal-700 text-xs font-semibold"
                      title={t}
                    >
                      {initialsFor(t)}
                    </span>
                  ))}
                </div>
              </article>
            ))}
          </div>

          {filteredProjects.length === 0 && (
            <div className="mt-8 text-center text-gray-500 dark:text-gray-300">
              No projects match your criteria.
            </div>
          )}
        </section>
      </main>

      {/* Modal: Create/Edit Project */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center">
          <div className="absolute inset-0 bg-black bg-opacity-40" aria-label="modal-backdrop" onClick={() => setModalOpen(false)} />
          <div className="relative bg-white dark:bg-gray-800 w-full max-w-xl mx-4 rounded-xl shadow-xl overflow-hidden transform transition-all duration-300">
            <header className="px-6 py-4 border-b border-gray-200 dark:border-gray-700 flex items-center justify-between">
              <h2 className="text-lg font-semibold" style={{ fontFamily: 'Inter, ui-sans-serif' }}>
                {editing ? 'Edit Project' : 'Create Project'}
              </h2>
              <button
                onClick={() => setModalOpen(false)}
                className="text-gray-600 dark:text-gray-300 hover:text-gray-800 dark:hover:text-gray-100"
                aria-label="Close"
              >
                ✕
              </button>
            </header>

            <div className="p-6">
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  saveProject();
                }}
                className="space-y-4"
              >
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-200 mb-1">Title</label>
                  <input
                    type="text"
                    value={form.title}
                    onChange={(e) => setForm({ ...form, title: e.target.value })}
                    className="w-full rounded-md border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 text-gray-800 dark:text-gray-100 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-teal-300 transition-colors"
                    placeholder="e.g., Implement OAuth 2.0 login"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-200 mb-1">Description</label>
                  <textarea
                    rows={3}
                    value={form.description}
                    onChange={(e) => setForm({ ...form, description: e.target.value })}
                    className="w-full rounded-md border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 text-gray-800 dark:text-gray-100 px-3 py-2 resize-vertical focus:outline-none focus:ring-2 focus:ring-teal-300 transition-colors"
                    placeholder="Brief description of the project..."
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-200 mb-1">Status</label>
                    <select
                      value={form.status}
                      onChange={(e) => setForm({ ...form, status: e.target.value })}
                      className="w-full rounded-md border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 text-gray-800 dark:text-gray-100 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-teal-300 transition-colors"
                    >
                      {['Not Started', 'In Progress', 'Review', 'Done'].map((s) => (
                        <option key={s} value={s}>
                          {s}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-200 mb-1">Due Date</label>
                    <input
                      type="date"
                      value={form.dueDate}
                      onChange={(e) => setForm({ ...form, dueDate: e.target.value })}
                      className="w-full rounded-md border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 text-gray-800 dark:text-gray-100 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-teal-300 transition-colors"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-200 mb-1">Progress</label>
                  <input
                    type="range"
                    min={0}
                    max={100}
                    value={form.progress}
                    onChange={(e) => setForm({ ...form, progress: Number(e.target.value) })}
                    className="w-full"
                  />
                  <div className="text-xs text-gray-500 dark:text-gray-300 mt-1">
                    {form.progress}%
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-200 mb-1">Assign Teams</label>
                  <div className="flex flex-wrap gap-2">
                    {initialTeams.map((t) => {
                      const active = selectedTeams.includes(t);
                      return (
                        <button
                          type="button"
                          key={t}
                          onClick={() => toggleTeam(t)}
                          className={`px-3 py-2 rounded-md border ${
                            active
                              ? 'bg-teal-100 text-teal-700 border-teal-200'
                              : 'bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-100 border-gray-200 dark:border-gray-700'
                          } hover:bg-teal-50 dark:hover:bg-teal-900 transition-colors`}
                          aria-pressed={active}
                          title={t}
                        >
                          {t}
                          {active ? ' ✓' : ''}
                        </button>
                      );
                    })}
                  </div>
                </div>

                <div className="flex items-center justify-end gap-3 pt-2">
                  <button
                    type="button"
                    className="px-4 py-2 rounded-md border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 text-gray-700 dark:text-gray-100 hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors"
                    onClick={() => setModalOpen(false)}
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 rounded-md bg-[#1A2B4A] text-white hover:bg-[#0f2140] transition-colors"
                  >
                    {editing ? 'Save Changes' : 'Create Project'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}