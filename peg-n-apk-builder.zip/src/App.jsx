import { Routes, Route, Link } from "react-router-dom";
import Home from "./pages/Home.jsx";
import Engineers from "./pages/Engineers.jsx";
import EngineersId from "./pages/EngineersId.jsx";
import Projects from "./pages/Projects.jsx";
import ProjectsId from "./pages/ProjectsId.jsx";
import Messages from "./pages/Messages.jsx";
import AdminUsers from "./pages/AdminUsers.jsx";
import Analytics from "./pages/Analytics.jsx";

export default function App() {
  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col">
      <header className="sticky top-0 z-40 backdrop-blur bg-slate-950/80 border-b border-white/10">
        <nav className="max-w-6xl mx-auto flex items-center gap-2 px-4 py-3 overflow-x-auto">
          <Link to="/" className="font-bold text-base mr-2 whitespace-nowrap">engineer-network-hub</Link>
          <div className="flex gap-1 ml-auto">
          <Link to="/" className="px-3 py-2 rounded-lg text-sm text-slate-300 hover:bg-white/10 hover:text-white transition">Dashboard</Link>
          <Link to="/engineers" className="px-3 py-2 rounded-lg text-sm text-slate-300 hover:bg-white/10 hover:text-white transition">Engineers Directory</Link>
          <Link to="/engineers/:id" className="px-3 py-2 rounded-lg text-sm text-slate-300 hover:bg-white/10 hover:text-white transition">Engineer Profile</Link>
          <Link to="/projects" className="px-3 py-2 rounded-lg text-sm text-slate-300 hover:bg-white/10 hover:text-white transition">Projects Board</Link>
          <Link to="/projects/:id" className="px-3 py-2 rounded-lg text-sm text-slate-300 hover:bg-white/10 hover:text-white transition">Project Details</Link>
          <Link to="/messages" className="px-3 py-2 rounded-lg text-sm text-slate-300 hover:bg-white/10 hover:text-white transition">Messaging Center</Link>
          <Link to="/admin/users" className="px-3 py-2 rounded-lg text-sm text-slate-300 hover:bg-white/10 hover:text-white transition">User Management</Link>
          <Link to="/analytics" className="px-3 py-2 rounded-lg text-sm text-slate-300 hover:bg-white/10 hover:text-white transition">Analytics & Reports</Link>
          </div>
        </nav>
      </header>
      <main className="flex-1">
        <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/engineers" element={<Engineers />} />
        <Route path="/engineers/:id" element={<EngineersId />} />
        <Route path="/projects" element={<Projects />} />
        <Route path="/projects/:id" element={<ProjectsId />} />
        <Route path="/messages" element={<Messages />} />
        <Route path="/admin/users" element={<AdminUsers />} />
        <Route path="/analytics" element={<Analytics />} />
        </Routes>
      </main>
      <footer className="border-t border-white/10 py-4 text-center text-xs text-slate-500">
        © 2026 engineer-network-hub
      </footer>
    </div>
  );
}
