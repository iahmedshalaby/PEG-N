const express = require('express');
const { v4: uuidv4 } = require('uuid');

const router = express.Router();

// ============= In-Memory Data Store =============
const store = {
  users: [],
  engineers: [],
  projects: [],
  tasks: [],
  messages: [],
  reviews: [],
  notifications: [],
  sessions: {} // For JWT simulation
};

// ============= Utility Functions =============
const generateToken = () => Math.random().toString(36).substring(2, 15);
const getCurrentTimestamp = () => new Date().toISOString();
const getCurrentDate = () => new Date().toISOString().split('T')[0];

// Mock middleware for authentication
const authMiddleware = (req, res, next) => {
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) {
    return res.status(401).json({ error: 'Unauthorized' });
  }
  const session = Object.values(store.sessions).find(s => s.token === token);
  if (!session) {
    return res.status(401).json({ error: 'Invalid token' });
  }
  req.userId = session.userId;
  next();
};

const adminMiddleware = (req, res, next) => {
  const user = store.users.find(u => u.id === req.userId);
  if (!user || user.role !== 'ADMIN') {
    return res.status(403).json({ error: 'Forbidden' });
  }
  next();
};

// ============= Auth Endpoints =============

// POST /api/auth/register
router.post('/auth/register', (req, res) => {
  const { email, password, firstName, lastName, role } = req.body;

  if (!email || !password) {
    return res.status(400).json({ error: 'Email and password required' });
  }

  if (store.users.find(u => u.email === email)) {
    return res.status(409).json({ error: 'Email already registered' });
  }

  const user = {
    id: uuidv4(),
    email,
    passwordHash: Buffer.from(password).toString('base64'),
    firstName: firstName || '',
    lastName: lastName || '',
    role: role || 'ENGINEER',
    isVerified: false,
    isActive: true,
    createdAt: getCurrentTimestamp(),
    updatedAt: getCurrentTimestamp()
  };

  store.users.push(user);

  res.status(201).json({
    id: user.id,
    email: user.email,
    message: 'User registered successfully. Please verify your email.'
  });
});

// POST /api/auth/login
router.post('/auth/login', (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ error: 'Email and password required' });
  }

  const user = store.users.find(u => u.email === email);
  if (!user) {
    return res.status(401).json({ error: 'Invalid credentials' });
  }

  const passwordHash = Buffer.from(password).toString('base64');
  if (user.passwordHash !== passwordHash) {
    return res.status(401).json({ error: 'Invalid credentials' });
  }

  if (!user.isActive) {
    return res.status(403).json({ error: 'User account is inactive' });
  }

  const accessToken = generateToken();
  const refreshToken = generateToken();

  store.sessions[user.id] = {
    userId: user.id,
    token: accessToken,
    refreshToken,
    createdAt: getCurrentTimestamp()
  };

  res.status(200).json({
    accessToken,
    refreshToken,
    user: {
      id: user.id,
      email: user.email,
      firstName: user.firstName,
      lastName: user.lastName,
      role: user.role
    }
  });
});

// POST /api/auth/refresh
router.post('/auth/refresh', (req, res) => {
  const { refreshToken } = req.body;

  if (!refreshToken) {
    return res.status(400).json({ error: 'Refresh token required' });
  }

  const session = Object.values(store.sessions).find(s => s.refreshToken === refreshToken);
  if (!session) {
    return res.status(401).json({ error: 'Invalid refresh token' });
  }

  const newAccessToken = generateToken();
  session.token = newAccessToken;

  res.status(200).json({ accessToken: newAccessToken });
});

// POST /api/auth/logout
router.post('/auth/logout', authMiddleware, (req, res) => {
  delete store.sessions[req.userId];
  res.status(200).json({ message: 'Logged out successfully' });
});

// ============= Engineer Endpoints =============

// GET /api/engineers
router.get('/engineers', (req, res) => {
  const { page = 1, limit = 10, specialty, minRating, sortBy = 'rating' } = req.query;

  let engineers = store.engineers.map(eng => {
    const user = store.users.find(u => u.id === eng.userId);
    return { ...eng, user };
  });

  if (specialty) {
    engineers = engineers.filter(e => e.specialty.toLowerCase().includes(specialty.toLowerCase()));
  }

  if (minRating) {
    engineers = engineers.filter(e => e.rating >= parseFloat(minRating));
  }

  engineers.sort((a, b) => {
    if (sortBy === 'rating') return b.rating - a.rating;
    if (sortBy === 'experience') return b.yearsExperience - a.yearsExperience;
    return 0;
  });

  const start = (page - 1) * limit;
  const paginated = engineers.slice(start, start + parseInt(limit));

  res.status(200).json({
    data: paginated,
    pagination: { page: parseInt(page), limit: parseInt(limit), total: engineers.length }
  });
});

// GET /api/engineers/:id
router.get('/engineers/:id', (req, res) => {
  const engineer = store.engineers.find(e => e.id === req.params.id);
  if (!engineer) {
    return res.status(404).json({ error: 'Engineer not found' });
  }

  const user = store.users.find(u => u.id === engineer.userId);
  const reviews = store.reviews.filter(r => r.engineerId === engineer.id);
  const projects = store.projects.filter(p => p.assignedEngineers.includes(engineer.id));

  res.status(200).json({
    ...engineer,
    user,
    reviews,
    portfolioProjects: projects
  });
});

// PUT /api/engineers/:id
router.put('/engineers/:id', authMiddleware, (req, res) => {
  const engineer = store.engineers.find(e => e.id === req.params.id);
  if (!engineer) {
    return res.status(404).json({ error: 'Engineer not found' });
  }

  const { specialty, skills, bio, hourlyRate, isAvailable, certifications } = req.body;

  if (specialty) engineer.specialty = specialty;
  if (skills) engineer.skills = skills;
  if (bio) engineer.bio = bio;
  if (hourlyRate !== undefined) engineer.hourlyRate = hourlyRate;
  if (isAvailable !== undefined) engineer.isAvailable = isAvailable;
  if (certifications) engineer.certifications = certifications;

  res.status(200).json(engineer);
});

// ============= Project Endpoints =============

// POST /api/projects
router.post('/projects', authMiddleware, (req, res) => {
  const { title, description, budget, startDate, dueDate, assignedEngineers } = req.body;

  if (!title) {
    return res.status(400).json({ error: 'Title required' });
  }

  const project = {
    id: uuidv4(),
    title,
    description: description || '',
    status: 'PLANNING',
    budget: budget || 0,
    startDate: startDate || getCurrentDate(),
    dueDate: dueDate || getCurrentDate(),
    projectManagerId: req.userId,
    assignedEngineers: assignedEngineers || [],
    progress: 0,
    createdAt: getCurrentTimestamp()
  };

  store.projects.push(project);

  res.status(201).json(project);
});

// GET /api/projects
router.get('/projects', (req, res) => {
  const { page = 1, limit = 10, status } = req.query;

  let projects = store.projects;

  if (status) {
    projects = projects.filter(p => p.status === status);
  }

  const start = (page - 1) * limit;
  const paginated = projects.slice(start, start + parseInt(limit));

  res.status(200).json({
    data: paginated,
    pagination: { page: parseInt(page), limit: parseInt(limit), total: projects.length }
  });
});

// GET /api/projects/:id
router.get('/projects/:id', (req, res) => {
  const project = store.projects.find(p => p.id === req.params.id);
  if (!project) {
    return res.status(404).json({ error: 'Project not found' });
  }

  const tasks = store.tasks.filter(t => t.projectId === project.id);
  const team = project.assignedEngineers.map(engId => store.engineers.find(e => e.id === engId)).filter(Boolean);

  res.status(200).json({
    ...project,
    tasks,
    team
  });
});

// PUT /api/projects/:id
router.put('/projects/:id', authMiddleware, (req, res) => {
  const project = store.projects.find(p => p.id === req.params.id);
  if (!project) {
    return res.status(404).json({ error: 'Project not found' });
  }

  const { title, description, status, budget, dueDate, assignedEngineers, progress } = req.body;

  if (title) project.title = title;
  if (description) project.description = description;
  if (status) project.status = status;
  if (budget !== undefined) project.budget = budget;
  if (dueDate) project.dueDate = dueDate;
  if (assignedEngineers) project.assignedEngineers = assignedEngineers;
  if (progress !== undefined) project.progress = progress;

  res.status(200).json(project);
});

// ============= Task Endpoints =============

// POST /api/projects/:id/tasks
router.post('/projects/:id/tasks', authMiddleware, (req, res) => {
  const project = store.projects.find(p => p.id === req.params.id);
  if (!project) {
    return res.status(404).json({ error: 'Project not found' });
  }

  const { title, description, assignedTo, dueDate, priority } = req.body;

  if (!title) {
    return res.status(400).json({ error: 'Title required' });
  }

  const task = {
    id: uuidv4(),
    projectId: project.id,
    title,
    description: description || '',
    status: 'TODO',
    assignedTo: assignedTo || null,
    dueDate: dueDate || getCurrentDate(),
    priority: priority || 'MEDIUM',
    completionPercentage: 0
  };

  store.tasks.push(task);

  res.status(201).json(task);
});

// PUT /api/tasks/:id
router.put('/tasks/:id', authMiddleware, (req, res) => {
  const task = store.tasks.find(t => t.id === req.params.id);
  if (!task) {
    return res.status(404).json({ error: 'Task not found' });
  }

  const { status, assignedTo, dueDate, priority, completionPercentage } = req.body;

  if (status) task.status = status;
  if (assignedTo) task.assignedTo = assignedTo;
  if (dueDate) task.dueDate = dueDate;
  if (priority) task.priority = priority;
  if (completionPercentage !== undefined) task.completionPercentage = completionPercentage;

  res.status(200).json(task);
});

// ============= Message Endpoints =============

// GET /api/messages
router.get('/messages', authMiddleware, (req, res) => {
  const { recipientId, page = 1, limit = 20 } = req.query;

  if (!recipientId) {
    return res.status(400).json({ error: 'Recipient ID required' });
  }

  let messages = store.messages.filter(
    m => (m.senderId === req.userId && m.recipientId === recipientId) ||
         (m.senderId === recipientId && m.recipientId === req.userId)
  );

  messages.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

  const start = (page - 1) * limit;
  const paginated = messages.slice(start, start + parseInt(limit));

  res.status(200).json({
    data: paginated,
    pagination: { page: parseInt(page), limit: parseInt(limit), total: messages.length }
  });
});

// POST /api/messages
router.post('/messages', authMiddleware, (req, res) => {
  const { recipientId, projectId, content, attachments } = req.body;

  if (!recipientId || !content) {
    return res.status(400).json({ error: 'Recipient ID and content required' });
  }

  const message = {
    id: uuidv4(),
    senderId: req.userId,
    recipientId,
    projectId: projectId || null,
    content,
    attachments: attachments || [],
    isRead: false,
    createdAt: getCurrentTimestamp()
  };

  store.messages.push(message);

  res.status(201).json(message);
});

// ============= Notification Endpoints =============

// GET /api/notifications
router.get('/notifications', authMiddleware, (req, res) => {
  const notifications = store.notifications.filter(n => n.userId === req.userId);
  const unreadCount = notifications.filter(n => !n.isRead).length;

  res.status(200).json({
    data: notifications,
    unreadCount
  });
});

// PUT /api/notifications/:id/read
router.put('/notifications/:id/read', authMiddleware, (req, res) => {
  const notification = store.notifications.find(n => n.id === req.params.id);
  if (!notification) {
    return res.status(404).json({ error: 'Notification not found' });
  }

  notification.isRead = true;

  res.status(200).json(notification);
});

// ============= Review Endpoints =============

// POST /api/reviews
router.post('/reviews', authMiddleware, (req, res) => {
  const { engineerId, projectId, rating, comment } = req.body;

  if (!engineerId || !projectId || !rating) {
    return res.status(400).json({ error: 'Engineer ID, project ID, and rating required' });
  }

  if (rating < 1 || rating > 5) {
    return res.status(400).json({ error: 'Rating must be between 1 and 5' });
  }

  const review = {
    id: uuidv4(),
    engineerId,
    projectId,
    rating,
    comment: comment || '',
    createdAt: getCurrentTimestamp()
  };

  store.reviews.push(review);

  // Update engineer rating
  const engineer = store.engineers.find(e => e.id === engineerId);
  if (engineer) {
    const engineerReviews = store.reviews.filter(r => r.engineerId === engineerId);
    const avgRating = engineerReviews.reduce((sum, r) => sum + r.rating, 0) / engineerReviews.length;
    engineer.rating = parseFloat(avgRating.toFixed(1));
    engineer.reviewCount = engineerReviews.length;
  }

  res.status(201).json(review);
});

// ============= Analytics Endpoints =============

// GET /api/analytics/dashboard
router.get('/analytics/dashboard', authMiddleware, (req, res) => {
  const totalProjects = store.projects.length;
  const completedProjects = store.projects.filter(p => p.status === 'COMPLETED').length;
  const totalEngineers = store.engineers.length;
  const activeUsers = store.users.filter(u => u.isActive).length;
  const totalBudget = store.projects.reduce((sum, p) => sum + (p.budget || 0), 0);
  const averageProjectProgress = store.projects.length > 0
    ? store.projects.reduce((sum, p) => sum + p.progress, 0) / store.projects.length
    : 0;

  res.status(200).json({
    totalProjects,
    completedProjects,
    totalEngineers,
    activeUsers,
    totalBudget,
    averageProjectProgress: parseFloat(averageProjectProgress.toFixed(1)),
    timestamp: getCurrentTimestamp()
  });
});

// ============= Admin Endpoints =============

// GET /api/admin/users
router.get('/admin/users', authMiddleware, adminMiddleware, (req, res) => {
  const users = store.users.map(u => ({
    id: u.id,
    email: u.email,
    firstName: u.firstName,
    lastName: u.lastName,
    role: u.role,
    isVerified: u.isVerified,
    isActive: u.isActive,
    createdAt: u.createdAt
  }));

  res.status(200).json({ data: users });
});

// PUT /api/admin/users/:id/role
router.put('/admin/users/:id/role', authMiddleware, adminMiddleware, (req, res) => {
  const { role } = req.body;

  if (!role || !['ADMIN', 'ENGINEER', 'PROJECT_MANAGER'].includes(role)) {
    return res.status(400).json({ error: 'Invalid role' });
  }

  const user = store.users.find(u => u.id === req.params.id);
  if (!user) {
    return res.status(404).json({ error: 'User not found' });
  }

  user.role = role;
  user.updatedAt = getCurrentTimestamp();

  res.status(200).json({ message: 'Role updated successfully', user });
});

// PUT /api/admin/users/:id/status
router.put('/admin/users/:id/status', authMiddleware, adminMiddleware, (req, res) => {
  const { isActive } = req.body;

  const user = store.users.find(u => u.id === req.params.id);
  if (!user) {
    return res.status(404).json({ error: 'User not found' });
  }

  user.isActive = isActive;
  user.updatedAt = getCurrentTimestamp();

  res.status(200).json({ message: 'User status updated successfully', user });
});

// ============= Seed Data =============
const seedData = () => {
  // Create sample users
  const user1 = {
    id: uuidv4(),
    email: 'john@example.com',
    passwordHash: Buffer.from('password123').toString('base64'),
    firstName: 'John',
    lastName: 'Doe',
    role: 'ENGINEER',
    isVerified: true,
    isActive: true,
    createdAt: getCurrentTimestamp(),
    updatedAt: getCurrentTimestamp()
  };

  const user2 = {
    id: uuidv4(),
    email: 'jane@example.com',
    passwordHash: Buffer.from('password123').toString('base64'),
    firstName: 'Jane',
    lastName: 'Smith',
    role: 'PROJECT_MANAGER',
    isVerified: true,
    isActive: true,
    createdAt: getCurrentTimestamp(),
    updatedAt: getCurrentTimestamp()
  };

  store.users.push(user1, user2);

  // Create sample engineer
  const engineer = {
    id: uuidv4(),
    userId: user1.id,
    specialty: 'Full Stack Development',
    skills: ['JavaScript', 'React', 'Node.js', 'MongoDB'],
    bio: 'Experienced full stack developer with 5 years in the industry',
    hourlyRate: 75.00,
    rating: 4.8,
    reviewCount: 12,
    yearsExperience: 5,
    isAvailable: true,
    profileImageUrl: 'https://example.com/john.jpg',
    certifications: [{ name: 'AWS Certified', issuedAt: '2022-01-15' }],
    portfolioProjects: []
  };

  store.engineers.push(engineer);

  // Create sample project
  const project = {
    id: uuidv4(),
    title: 'E-commerce Platform Redesign',
    description: 'Complete redesign of the existing e-commerce platform',
    status: 'IN_PROGRESS',
    budget: 50000.00,
    startDate: getCurrentDate(),
    dueDate: '2026-08-31',
    projectManagerId: user2.id,
    assignedEngineers: [engineer.id],
    progress: 65,
    createdAt: getCurrentTimestamp()
  };

  store.projects.push(project);
};

seedData();

module.exports = router;