# Backend

Generated stub for engineer-network-hub. Run with `node server/index.js` after wiring an Express server.